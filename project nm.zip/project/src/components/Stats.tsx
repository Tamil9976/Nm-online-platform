import React from 'react';
import { Users, BookOpen, Award } from 'lucide-react';

const stats = [
  {
    icon: <Users className="h-6 w-6" />,
    label: 'Active Students',
    value: '10,000+',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100'
  },
  {
    icon: <BookOpen className="h-6 w-6" />,
    label: 'Total Courses',
    value: '150+',
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  {
    icon: <Award className="h-6 w-6" />,
    label: 'Certificates Awarded',
    value: '5,000+',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100'
  }
];

export default function Stats() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center">
                <div className={`${stat.bgColor} ${stat.color} p-3 rounded-lg`}>
                  {stat.icon}
                </div>
                <div className="ml-4">
                  <p className="text-gray-600">{stat.label}</p>
                  <h4 className="text-2xl font-bold text-gray-900">{stat.value}</h4>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}