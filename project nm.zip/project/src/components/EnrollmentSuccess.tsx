import React from 'react';
import { CheckCircle, PlayCircle, BookOpen, MessageCircle } from 'lucide-react';

interface EnrollmentSuccessProps {
  courseTitle: string;
  onStart: () => void;
  onClose: () => void;
}

export default function EnrollmentSuccess({ courseTitle, onStart, onClose }: EnrollmentSuccessProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
        <div className="text-center mb-6">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Enrollment Successful!</h2>
          <p className="text-gray-600">You're now enrolled in {courseTitle}</p>
        </div>

        <div className="space-y-4 mb-6">
          <div className="flex items-center p-4 bg-gray-50 rounded-lg">
            <PlayCircle className="h-6 w-6 text-indigo-600 mr-3" />
            <div>
              <h3 className="font-semibold">Start Learning</h3>
              <p className="text-sm text-gray-600">Access your course content</p>
            </div>
          </div>
          
          <div className="flex items-center p-4 bg-gray-50 rounded-lg">
            <BookOpen className="h-6 w-6 text-indigo-600 mr-3" />
            <div>
              <h3 className="font-semibold">Course Materials</h3>
              <p className="text-sm text-gray-600">Download resources</p>
            </div>
          </div>
          
          <div className="flex items-center p-4 bg-gray-50 rounded-lg">
            <MessageCircle className="h-6 w-6 text-indigo-600 mr-3" />
            <div>
              <h3 className="font-semibold">Community Access</h3>
              <p className="text-sm text-gray-600">Join course discussions</p>
            </div>
          </div>
        </div>

        <div className="flex space-x-4">
          <button
            onClick={onStart}
            className="flex-1 bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition"
          >
            Start Course
          </button>
          <button
            onClick={onClose}
            className="flex-1 border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition"
          >
            View Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}