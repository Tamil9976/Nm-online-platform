import React from 'react';
import { Code, Database, Globe, Server } from 'lucide-react';

const categories = [
  {
    icon: <Code className="h-6 w-6" />,
    name: 'Frontend Development',
    count: 24,
    color: 'text-blue-600',
    bgColor: 'bg-blue-100'
  },
  {
    icon: <Server className="h-6 w-6" />,
    name: 'Backend Development',
    count: 18,
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  {
    icon: <Database className="h-6 w-6" />,
    name: 'Database Design',
    count: 12,
    color: 'text-purple-600',
    bgColor: 'bg-purple-100'
  },
  {
    icon: <Globe className="h-6 w-6" />,
    name: 'Full Stack',
    count: 15,
    color: 'text-orange-600',
    bgColor: 'bg-orange-100'
  }
];

export default function Categories() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Browse Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <div 
              key={category.name}
              className="flex items-center p-6 rounded-xl border hover:border-indigo-600 transition cursor-pointer"
            >
              <div className={`${category.bgColor} ${category.color} p-3 rounded-lg`}>
                {category.icon}
              </div>
              <div className="ml-4">
                <h3 className="font-semibold text-gray-900">{category.name}</h3>
                <p className="text-gray-600">{category.count} courses</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}