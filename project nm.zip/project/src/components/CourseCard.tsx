import React, { useState } from 'react';
import { Clock, Star, Users } from 'lucide-react';
import EnrollmentSuccess from './EnrollmentSuccess';

interface CourseCardProps {
  title: string;
  image: string;
  instructor: string;
  level: string;
  duration: string;
  rating: number;
  students?: number;
}

export default function CourseCard({ 
  title, 
  image, 
  instructor, 
  level, 
  duration, 
  rating,
  students = 0
}: CourseCardProps) {
  const [showEnrollment, setShowEnrollment] = useState(false);

  const handleEnroll = () => {
    // Here you would typically make an API call to enroll the user
    setShowEnrollment(true);
  };

  const handleStartCourse = () => {
    // Navigate to course content
    console.log('Starting course:', title);
    setShowEnrollment(false);
  };

  const handleClose = () => {
    // Navigate to dashboard
    console.log('Navigating to dashboard');
    setShowEnrollment(false);
  };

  return (
    <>
      <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition">
        <img src={image} alt={title} className="w-full h-48 object-cover" />
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2">{title}</h3>
          <p className="text-gray-600 mb-4">by {instructor}</p>
          
          <div className="flex justify-between items-center mb-4">
            <span className="bg-indigo-100 text-indigo-800 text-sm px-3 py-1 rounded-full">
              {level}
            </span>
            <div className="flex items-center text-gray-600">
              <Clock className="h-4 w-4 mr-1" />
              <span className="text-sm">{duration}</span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400" />
                <span className="ml-1 text-gray-600">{rating}</span>
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4 text-gray-400" />
                <span className="ml-1 text-gray-600">{students}</span>
              </div>
            </div>
            <button 
              onClick={handleEnroll}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition transform hover:scale-105 active:scale-95"
            >
              Enroll Now
            </button>
          </div>
        </div>
      </div>

      {showEnrollment && (
        <EnrollmentSuccess
          courseTitle={title}
          onStart={handleStartCourse}
          onClose={handleClose}
        />
      )}
    </>
  );
}