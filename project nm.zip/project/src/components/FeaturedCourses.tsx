import React from 'react';
import CourseCard from './CourseCard';

const courses = [
  {
    id: 1,
    title: 'MongoDB Mastery',
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&w=800&q=80',
    instructor: 'Sarah Johnson',
    level: 'Intermediate',
    duration: '8 weeks',
    rating: 4.8,
    students: 1234
  },
  {
    id: 2,
    title: 'Express.js Deep Dive',
    image: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?auto=format&fit=crop&w=800&q=80',
    instructor: 'Mike Chen',
    level: 'Advanced',
    duration: '10 weeks',
    rating: 4.9,
    students: 856
  },
  {
    id: 3,
    title: 'React Frontend Masters',
    image: 'https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?auto=format&fit=crop&w=800&q=80',
    instructor: 'Alex Rivera',
    level: 'Beginner',
    duration: '12 weeks',
    rating: 4.7,
    students: 2341
  },
];

export default function FeaturedCourses() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Featured Courses</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Start your journey with our most popular courses, designed to take you from beginner to professional.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {courses.map((course) => (
            <CourseCard
              key={course.id}
              title={course.title}
              image={course.image}
              instructor={course.instructor}
              level={course.level}
              duration={course.duration}
              rating={course.rating}
              students={course.students}
            />
          ))}
        </div>
      </div>
    </section>
  );
}