import express from 'express';
import Course from '../models/Course.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Get all courses
router.get('/', async (req, res) => {
  try {
    const courses = await Course.find()
      .populate('instructor', 'name')
      .select('-reviews');
    res.json(courses);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get single course
router.get('/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate('instructor', 'name')
      .populate('reviews.user', 'name');
    
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    
    res.json(course);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Create course (instructors only)
router.post('/', auth, async (req, res) => {
  try {
    const { title, description, image, level, duration, price } = req.body;
    
    const course = new Course({
      title,
      description,
      instructor: req.user.userId,
      image,
      level,
      duration,
      price
    });

    await course.save();
    res.status(201).json(course);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Enroll in course
router.post('/:id/enroll', auth, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    if (course.students.includes(req.user.userId)) {
      return res.status(400).json({ message: 'Already enrolled' });
    }

    course.students.push(req.user.userId);
    await course.save();

    res.json({ message: 'Successfully enrolled' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Add review
router.post('/:id/reviews', auth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    const review = {
      user: req.user.userId,
      rating,
      comment
    };

    course.reviews.push(review);
    
    // Update course rating
    const totalRating = course.reviews.reduce((acc, item) => acc + item.rating, 0);
    course.rating = totalRating / course.reviews.length;
    
    await course.save();
    res.status(201).json(review);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;